/**
 * Honor code
 * Eric Zhao
 */

package assignment;

import java.util.ArrayList;
import java.util.Stack;

public class Board {
    //game icons
    final public static String water = "~";
    final public static String ship = "@";
    final public static String sunk = "#";
    final public static String hit = "X";
    final public static String miss = "O";

    // The ships currently on the board
    private final ArrayList<Ship> ships;
    // All guesses currently made on this board
    private final Stack<Coordinates> fireHistory;
    // Whether ships should be hidden
    private boolean hideShips;

    /**
     * Constructs an empty board
     */
    public Board() {
        ships = new ArrayList<>();
        fireHistory = new Stack<>();
        hideShips = false;
    }

    public void setHideShips(boolean hideShips) {
        this.hideShips = hideShips;
    }

    /**
     * Checks if all ships on the board have been sunk
     *
     * @return A boolean indicating whether all ships have been sunk
     */
    public boolean areAllShipsSunk() {
        for (Ship ship : ships) {
            if (!ship.hasSunk())
                return false;
        }
        return true;
    }

    /**
     * Fires a shot at a given set of coordinates then adds those coordinates to fire history
     *
     * @return true if the shot was a hit
     */
    public boolean fire(Coordinates coords) {
        fireHistory.push(coords);
        for (Ship ship : ships) {
            if (ship.attemptHit(coords))
                return true;
        }
        return false;
    }

    /**
     * Adds a ship to the board, guarantees that ship will not intersect with
     *
     * @param ship the ship to add
     */
    public void addShip(Ship ship) throws Exception {
        for (Coordinates coords : ship.getSegmentCoords()) {
            if (coords.areInvalid()) {
                throw new Exception("Ship cannot be placed off of board");
            }
        }

        if (shipDoesIntersect(ship)) {
            throw new Exception("Ship intersects other ships on the board");
        }

        ships.add(ship);
    }

    /**
     * Rotates a ship safely, ensuring it doesn't intersect with any other ship
     *
     * @param ship the ship to rotate
     * @throws Exception an exception that indicated the ship would intersect another
     */
    public void rotateShip(Ship ship) throws Exception {
        Ship rotatedShip = new Ship(ship.getSize());
        rotatedShip.setCoords(ship.getCoords());
        rotatedShip.rotate();

        for (Ship other : ships) {
            if (!ship.getCoords().equals(other.getCoords())) { // Rules out the ship intersecting itself
                if (rotatedShip.doesIntersect(other)) {
                    throw new Exception("Cannot rotate ship as it would intersect another");
                }
            }
        }

        ship.rotate();
    }

    /**
     * Moves a ship safely, ensuring it doesn't intersect with any other ship
     *
     * @param ship the ship to move
     * @throws Exception an exception that indicated the ship would intersect another
     */
    public void moveShip(Ship ship, Coordinates coords) throws Exception {
        Ship movedShip = new Ship(ship.getSize());
        movedShip.setCoords(coords);
        movedShip.setRotation(ship.getRotation());

        for (Coordinates segmentCoords : movedShip.getSegmentCoords()) {
            if (segmentCoords.areInvalid()) {
                throw new Exception("Ship cannot be placed off of board");
            }
        }

        for (Ship other : ships) {
            if (!ship.getCoords().equals(other.getCoords())) { // Rules out the ship intersecting itself
                if (movedShip.doesIntersect(other)) {
                    throw new Exception("Cannot move ship as it would intersect another");
                }
            }
        }

        ship.setCoords(coords);
    }

    /**
     * Returns whether the given ship intersects any other ships on the board
     *
     * @return a boolean indicating  whether the given ship intersects any other ships on the board
     */
    public boolean shipDoesIntersect(Ship ship) {
        for (Ship other : ships) {
            if (ship.doesIntersect(other)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public String toString() {
        //ArrayList<ArrayList<String>> board =  new ArrayList<>();
        String[][] board = new String[10][10]; //coordinates are (y,x)

        //renders the entire board as water at first
        for (int y = 0; y < 10; y++) {
            for (int x = 0; x < 10; x++) {
                board[y][x] = water;
            }
        }

        //renders all fire history as misses
        Stack<?> fireHistoryClone = (Stack<?>) fireHistory.clone();
        while (!fireHistoryClone.isEmpty()) {
            Coordinates coords = (Coordinates) fireHistoryClone.pop();
            int y = coords.getY();
            int x = coords.getX();
            board[y][x] = miss;
        }

        //partitions sunken ships from the ones still afloat into separate ArrayLists for the next rendering steps
        ArrayList<Ship> sunkenShips = new ArrayList<>();
        ArrayList<Ship> stillAfloat = new ArrayList<>();
        for (Ship ship : ships) {
            if (ship.hasSunk())
                sunkenShips.add(ship);
            else
                stillAfloat.add(ship);
        }

        //renders all sunken ships
        for (Ship sunkenShip : sunkenShips) {
            Coordinates[] coords = sunkenShip.getSegmentCoords();

            //rendering coordinates of each sunken ship
            for (Coordinates c : coords) {
                board[c.getY()][c.getX()] = sunk;
            }
        }

        //renders the rest of the ships afloat with hits if there are any
        for (Ship afloatShip : stillAfloat) {
            Coordinates[] coords = afloatShip.getSegmentCoords(); //list of coordinates

            //rendering coordinates of each sunken ship
            for (int c = 0; c < coords.length; c++) {
                Coordinates co = coords[c];

                String shipPart = ship;
                if (afloatShip.isSegmentHit(c))
                    shipPart = hit;
                else if (hideShips) {
                    shipPart = water;
                }

                board[co.getY()][co.getX()] = shipPart;
            }
        }

        //rendering complete: water, misses, sunken ships, floating ships, and hits

        //sets up String representation to return
        StringBuilder renderedBoard = new StringBuilder("   0  1  2  3  4  5  6  7  8  9\n");
        for (int y = 0; y < board.length; y++) {
            renderedBoard.append(Character.toString('A' + y)).append("  ");
            for (int x = 0; x < board[y].length; x++) {
                renderedBoard.append(board[y][x]).append("  ");
            }
            renderedBoard.append("\n");
        }
        return renderedBoard.toString();
    }

    public static void main(String[] args) throws Exception {
        Board board = new Board();
        Ship ship1 = new Ship(5);
        Coordinates coords1 = new Coordinates(0,0);
        ship1.setCoords(coords1);
        board.addShip(ship1);
        System.out.println("has the ship sunk? "+board.areAllShipsSunk());
        System.out.println("firing on the ship now");
        Coordinates coords2 = new Coordinates(1,0);
        Coordinates coords3 = new Coordinates(2,0);
        Coordinates coords4 = new Coordinates(3,0);
        Coordinates coords5 = new Coordinates(4,0);
        board.fire(coords1);
        board.fire(coords2);
        board.fire(coords3);
        board.fire(coords4);
        board.fire(coords5);
        System.out.println("has the ship sunk? "+board.areAllShipsSunk());

        Ship ship3 = new Ship(5);
        Coordinates coords6 = new Coordinates(3,5);
        ship3.setCoords(coords6);
        board.addShip(ship3);
        System.out.println("rotation before rotating "+ship3.getRotation());
        board.rotateShip(ship3);
        System.out.println("rotation after rotating "+ship3.getRotation());

        Coordinates coords7 = new Coordinates(0,0);
        Coordinates coords8 = new Coordinates(3,0);
        ship1.setCoords(coords7);
        System.out.println("original coordinates "+ship1.getCoords().toString());
        board.moveShip(ship1, coords8);
        System.out.println("new coordinates "+ship1.getCoords().toString());

        Ship ship5 = new Ship(5);
        Ship ship6 = new Ship(3);
        Coordinates coords9 = new Coordinates(5,5);
        Coordinates coords10 = new Coordinates(5,5);
        ship5.setCoords(coords9);
        ship6.setCoords(coords10);
        System.out.println("do the two ships intersect? "+ship5.doesIntersect(ship6));

    }
}
