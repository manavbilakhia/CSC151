/**
 * Honor code
 * Saeed AlSuwaidi
 */

package assignment;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CoordinatesTest {

    @Test
    @DisplayName("Testing blank Coordinate constructor")
    public void blackCoordinates() {
        Coordinates testCoords = new Coordinates();
        assertEquals(0, testCoords.getX());
        assertEquals(0, testCoords.getY());
    }

    @Test
    @DisplayName("Testing numeric Coordinate constructor")
    public void numericCoordinates() {
        Coordinates testCoords = new Coordinates(6, 9);
        assertEquals(6, testCoords.getX());
        assertEquals(9, testCoords.getY());
    }

    @Test
    @DisplayName("Testing alphanumeric Coordinate constructor")
    public void letterNumberCoordinates() {
        try {
            Coordinates testCoords = new Coordinates("G9");
            assertEquals(9, testCoords.getX());
            assertEquals(6, testCoords.getY());
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    @DisplayName("Testing getBelow")
    public void getBelowTest() {
        Coordinates testCoords = new Coordinates(6, 6);
        testCoords = testCoords.getBelow(3);
        assertEquals(6, testCoords.getX());
        assertEquals(9, testCoords.getY());
    }

    @Test
    @DisplayName("Testing getAbove")
    public void getAboveTest() {
        Coordinates testCoords = new Coordinates(6, 6);
        testCoords = testCoords.getAbove(3);
        assertEquals(6, testCoords.getX());
        assertEquals(3, testCoords.getY());
    }

    @Test
    @DisplayName("Testing getLeft")
    public void getLeftTest() {
        Coordinates testCoords = new Coordinates(6, 6);
        testCoords = testCoords.getLeft(3);
        assertEquals(3, testCoords.getX());
        assertEquals(6, testCoords.getY());
    }

    @Test
    @DisplayName("Testing getRight")
    public void getRightTest() {
        Coordinates testCoords = new Coordinates(6, 6);
        testCoords = testCoords.getRight(3);
        assertEquals(9, testCoords.getX());
        assertEquals(6, testCoords.getY());
    }
}
