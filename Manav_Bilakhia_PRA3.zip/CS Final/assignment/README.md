# battleship
A CLI battleship game written in Java for CSC-151

## Running the code

Simply run the main method of the `Game` class to play. No external dependencies are required.

## Instructions on setting up git
1. First ensure you have git CLI installed by typing `git` in a command line. If you don't have it installed, [download it here](https://git-scm.com/downloads)
2. Next follow [this guide](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token) to get a GitHub personal access token
3. Clone this repository using [this guide](https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository)
4. Next type in the command `git checkout -b <your first name all lowercase (e.g. james)>`. This will make it so we can all work on seperate branches and I can merge them all in at the end to avoid you guys having to deal with any merge conflicts
5. Whenever you feel like you have a good save point run the following commands in order. Each time you do this you will be able to go back to this save point at any time and others can see the progress you've made.
```
git stage -A
git commit -m "A useful message"
git push
```
That's it! Reach out if you have any questions

## The project

The goal of this project will be to make a playable text based battleship game. The game will go like this

### 1. Placement
To start out players will position their ships while the other player looks away. Players will also enter their name to distinguish whose turn it is. The interface for doing this will look like this. (If we don't end up having time for this we will randomly generate layouts)

```
Enter your name: James
---

   0  1  2  3  4  5  6  7  8  9
A  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
B  ~  @  ~  ~  ~  ~  ~  ~  ~  ~
C  ~  @  ~  ~  ~  ~  ~  ~  ~  ~
D  ~  @  ~  ~  ~  ~  ~  ~  ~  ~
E  ~  @  ~  ~  ~  ~  ~  ~  ~  ~
F  ~  ~  ~  #  #  #  ~  ~  ~  ~
G  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
H  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
I  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
J  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~

~ = Water
@ = Selected ship
# = Placed ship
---

[R] Rotate ship
[← ↑ → ↓] Move ship (Arrow keys)
[Enter] Done / Next ship
```



### 2. Coordinates
Players will take turns entering coordinates on the board to try to sink the other player's ships
```
James's turn

   0  1  2  3  4  5  6  7  8  9
A  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
B  ~  ~  ~  ~  ~  ~  ~  ~  o  ~
C  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
D  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
E  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
F  ~  ~  ~  #  #  #  ~  ~  ~  ~
G  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
H  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
I  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
J  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~

~ = Water
o = Miss
X = Hit
# = Sunk
---

Enter a coordinate: A2
``` 

### 3. End
The game will end when a player sinks all the other players ships. When this happens the program should display the name of the winner and stop
