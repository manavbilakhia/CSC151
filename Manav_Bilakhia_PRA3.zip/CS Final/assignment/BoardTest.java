/**
 * Honor code
 * Eric Zhao
 */


package assignment;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BoardTest {

    @Test
    void areAllShipsSunk() throws Exception {
        Board board = new Board();
        Ship ship1 = new Ship(5);
        Coordinates coords1 = new Coordinates(0, 0);
        ship1.setCoords(coords1);
        board.addShip(ship1);
        assertFalse(board.areAllShipsSunk());
        Coordinates coords2 = new Coordinates(1, 0);
        Coordinates coords3 = new Coordinates(2, 0);
        Coordinates coords4 = new Coordinates(3, 0);
        Coordinates coords5 = new Coordinates(4, 0);
        board.fire(coords1);
        board.fire(coords2);
        board.fire(coords3);
        board.fire(coords4);
        board.fire(coords5);
        assertTrue(board.areAllShipsSunk());
    }

    @Test
    void rotateShip() throws Exception {
        Board board = new Board();
        Ship ship1 = new Ship(5);
        Coordinates coords1 = new Coordinates(0, 0);
        ship1.setCoords(coords1);
        board.addShip(ship1);
        board.rotateShip(ship1);
        assertEquals(ship1.getRotation(), "vertical");


    }

    @Test
    void moveShip() throws Exception {
        Board board = new Board();
        Ship ship1 = new Ship(5);
        Coordinates coords1 = new Coordinates(0, 0);
        Coordinates coords2 = new Coordinates(3, 0);
        ship1.setCoords(coords1);
        board.moveShip(ship1, coords2);
        assertEquals(ship1.getCoords(), coords2);


    }

    @Test
    void shipDoesIntersect() {
        Ship ship1 = new Ship(5);
        Ship ship2 = new Ship(3);
        Coordinates coords1 = new Coordinates(0, 0);
        Coordinates coords2 = new Coordinates(0, 0);
        ship1.setCoords(coords1);
        ship2.setCoords(coords2);
        assertTrue(ship1.doesIntersect(ship2));
    }
}