/**
 * Honor code
 * James Heffernan
 */


package assignment;

import java.util.Scanner;

public class ConsoleDriver {
    /**
     * Helper method for clearing the console
     */
    public static void clearConsole() {
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }

    /**
     * Helper method for creating a prompt with a board displayed above it
     *
     * @param board    the board to be displayed above the prompt
     * @param prompt   the prompt to be displayed beneath the board
     * @param reprompt true if this is not the first time this prompt has been tried. Prevents the board from showing again and burying the error message
     * @return the user input
     */
    public static String boardPrompt(Board board, String prompt, boolean reprompt) {
        Scanner sc = new Scanner(System.in);

        if (!reprompt) {
            System.out.print(board.toString() + "\n\n" + prompt);
        } else {
            System.out.println(prompt);
        }

        return sc.next();
    }

    /**
     * Helper method for creating a prompt with a board displayed above it and parsing the input as coordinates
     *
     * @param board    the board to be displayed above the prompt
     * @param prompt   the prompt to be displayed beneath the board
     * @param reprompt true if this is not the first time this prompt has been tried. Prevents the board from showing again and burying the error message
     * @return the user inputted coordinates, guaranteed to be valid
     */
    public static Coordinates boardCoordinatesPrompt(Board board, String prompt, boolean reprompt) {
        String coordsStr = boardPrompt(board, prompt, reprompt);

        Coordinates coords;
        try {
            coords = new Coordinates(coordsStr);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return boardCoordinatesPrompt(board, prompt, reprompt);
        }

        return coords;
    }
}
