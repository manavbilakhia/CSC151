/**
 * Honor code
 * Manav Bilakhia
 */
package assignment;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ShipTest {

    @Test
    @DisplayName("Testing default Ship Constructor")
    public void shipConstructorTest() {
        Ship testShip = new Ship(4);
        String expected = "@@@@";
        assertEquals(expected, testShip.toString());
    }

    @Test
    @DisplayName("attemptHit Test")
    void attemptHit() {
        Ship testShip = new Ship(4);
        Coordinates coords = new Coordinates(0, 0);
        assertTrue(testShip.attemptHit(coords));
    }

    @Test
    @DisplayName("hasSunk Test")
    void hasSunk() {
        Ship testShip = new Ship(2);
        Coordinates shot = new Coordinates(0, 0);
        testShip.attemptHit(shot);
        assertFalse(testShip.hasSunk());
        Coordinates shot2 = new Coordinates(1, 0);
        testShip.attemptHit(shot2);
        assertTrue(testShip.hasSunk());
    }

    @Test
    @DisplayName("getSize Test")
    void getSize() {
        Ship testShip = new Ship(2);
        assertEquals(2, testShip.getSize());
    }

    @Test
    @DisplayName("getCoords Test")
    void getCoords() {
        Coordinates expectedCoords = new Coordinates(0, 0);
        Ship testShip = new Ship(1);
        assertEquals(expectedCoords, testShip.getCoords());
    }

    @Test
    @DisplayName("setCoords Test")
    void setCoords() {
        Coordinates expectedCoords = new Coordinates(6, 9);
        Ship testShip = new Ship(1);
        testShip.setCoords(expectedCoords);
        assertEquals(expectedCoords, testShip.getCoords());
    }

    @Test
    @DisplayName("isSegmentHit Test")
    void isSegmentHit() {
        Ship testShip = new Ship(1);
        Coordinates shot = new Coordinates(0, 0);
        testShip.attemptHit(shot);
        assertTrue(testShip.isSegmentHit(0));
    }

    @Test
    @DisplayName("doesIntersect Test")
    void doesIntersect() {
        Ship testShip = new Ship(1);
        Ship testShip2 = new Ship(1);
        assertTrue(testShip.doesIntersect(testShip2));
        Coordinates expectedCoords = new Coordinates(6, 9);
        testShip2.setCoords(expectedCoords);
        assertFalse(testShip.doesIntersect(testShip2));
    }

    @Test
    @DisplayName("getSegmentCoords Test")
    void getSegmentCoords() {
        Ship testShip = new Ship(1);
        Coordinates expectedCoords = new Coordinates(0, 0);
        Coordinates[] expected = new Coordinates[1];
        expected[0] = expectedCoords;
        assertEquals(expected[0], testShip.getSegmentCoords()[0]);
    }

    @Test
    @DisplayName("rotate Test")
    void rotate() {
        Ship testShip = new Ship(1);
        assertEquals("horizontal", testShip.getRotation());
        testShip.rotate();
        assertEquals("vertical", testShip.getRotation());
    }

}
