/**
 * Honor code
 * Manav Bilakhia
 */

package assignment;

import java.util.Arrays;
import java.util.Objects;

public class Ship {
    final private static String HORIZONTAL_ROTATION = "horizontal";
    final private static String VERTICAL_ROTATION = "vertical";

    // The size of the ship
    final private int size;
    // An array of booleans indicating which part of the ship has been hit. true = hit, false = not hit
    final private boolean[] hits;
    // The coordinates of the segment of the ship closest to the top left of the board
    private Coordinates coords;
    // The rotation of the ship
    private String rotation;

    /**
     * Creates a new ship
     *
     * @param size the size of the ship
     */
    public Ship(int size) {
        rotation = HORIZONTAL_ROTATION;
        hits = new boolean[size];
        Arrays.fill(hits, false);
        coords = new Coordinates(0, 0);
        this.size = size;
    }

    /**
     * Attempts to hit the ship at given coordinates
     *
     * @return whether the ship was hit at these coordinates
     */
    public boolean attemptHit(Coordinates coordinates) {
        Coordinates[] shipCoords = this.getSegmentCoords();
        for (int i = 0; i < shipCoords.length; i++) {
            if (shipCoords[i].equals(coordinates)) {
                hits[i] = true;
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the ship has sunk
     *
     * @return A boolean indicating whether this ship has sunk
     */
    public boolean hasSunk() { //done
        for (int i = 0; i < size; i++) {
            if (!hits[i])
                return false;
        }
        return true;
    }

    /**
     * Gets the size of the ship
     *
     * @return the size
     */
    public int getSize() { //done
        return size;
    }

    /**
     * Gets the coordinates of the ship
     *
     * @return the coordinates of the ship
     */
    public Coordinates getCoords() { //done
        return coords;
    }

    /**
     * Sets the coords of a ship
     *
     * @param coords the coords
     */
    public void setCoords(Coordinates coords) { //done
        this.coords = coords;
    }

    /**
     * if index on the hits array is hit return true.
     *
     * @param index the index of the segment
     * @return whether this segment has been hit
     */
    public boolean isSegmentHit(int index) //done
    {
        return hits[index];
    }

    /**
     * Checks if this ship intersects with another ship
     *
     * @param other the other ship
     * @return whether this ship intersects the other
     */
    public boolean doesIntersect(Ship other) {
        Coordinates[] otherCoordinates = other.getSegmentCoords();

        for (Coordinates coords : getSegmentCoords()) {
            for (Coordinates otherCoords : otherCoordinates) {
                if (coords.equals(otherCoords)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Based on the rotation of the ship, retrieves an array of occupied coordinates.
     *
     * @return an array of coordinates the ship occupies
     */
    public Coordinates[] getSegmentCoords() // done
    {
        Coordinates[] occupiedCoords = new Coordinates[this.size];
        occupiedCoords[0] = this.coords;
        if (rotation.equals(HORIZONTAL_ROTATION)) {
            for (int i = 1; i < this.size; i++) {
                //Coordinates coordsToAdd = this.coords;
                occupiedCoords[i] = this.coords.getRight(i);
            }
        } else {
            for (int i = 1; i < this.size; i++) {
                occupiedCoords[i] = this.coords.getBelow(i);
            }
        }

        return occupiedCoords;
    }

    @Override
    public String toString() {
        return Board.ship.repeat(Math.max(0, size));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ship ship = (Ship) o;
        return size == ship.size && Arrays.equals(hits, ship.hits) && coords.equals(ship.coords) && rotation.equals(ship.rotation);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(size, coords, rotation);
        result = 31 * result + Arrays.hashCode(hits);
        return result;
    }

    public String getRotation() {
        return rotation;
    }

    public void setRotation(String rotation) {
        this.rotation = rotation;
    }

    /**
     * Rotates the ship horizontally or vertically
     */
    public void rotate() {
        if (rotation.equals(HORIZONTAL_ROTATION)) {
            rotation = VERTICAL_ROTATION;
            int segmentsOutOfBounds = 0;
            for (Coordinates coords : getSegmentCoords()) {
                if (coords.getY() > Coordinates.MAX_Y) {
                    segmentsOutOfBounds += 1;
                }
            }

            coords = coords.getAbove(segmentsOutOfBounds);
        } else {
            rotation = HORIZONTAL_ROTATION;
            int segmentsOutOfBounds = 0;
            for (Coordinates coords : getSegmentCoords()) {
                if (coords.getX() > Coordinates.MAX_X) {
                    segmentsOutOfBounds += 1;
                }
            }

            coords = coords.getLeft(segmentsOutOfBounds);
        }
    }

    public static void main(String[] args) {
        Ship testShip = new Ship(4);
        System.out.println("testShip should have a length of 4: " + testShip);

        Coordinates shot =  new Coordinates(0,0);
        System.out.println("Ship should be hit: " + testShip.attemptHit(shot));

        testShip = new Ship(2);
        shot =  new Coordinates(0,0);
        testShip.attemptHit(shot);
        System.out.println("Has the 2-length ship sunk after 1 successful shot?: " + testShip.hasSunk());
        Coordinates shot2 =  new Coordinates(1,0);
        testShip.attemptHit(shot2);
        System.out.println("Has the 2-length ship sunk after 2 successful shots?: " + testShip.hasSunk());

        System.out.println("2-length size ship has a size of: " + testShip.getSize());
        System.out.println("Default ship coordinates are (0,0): " + testShip.getCoords());
        Coordinates setCoords = new Coordinates(6,9);
        testShip.setCoords(setCoords);
        System.out.println("Ship coords should now be (6,9): " + testShip.getCoords());

        testShip = new Ship(1);
        shot = new Coordinates(0,0);
        System.out.println("This shot should hit: " + testShip.attemptHit(shot));

        System.out.println("Test ship orientation before rotation: " + testShip.getRotation());
        testShip.rotate();
        System.out.println("Test ship orientation after rotation: " + testShip.getRotation());

        Ship testShip2 = new Ship(1);
        System.out.println("These 2 ships should intersect: " + testShip.doesIntersect(testShip2));

    }
}