/**
 * Honor code
 * Saeed AlSuwaidi
 */


package assignment;

import java.util.Objects;

public class Coordinates {
    final public static int MIN_X = 0;
    final public static int MIN_Y = 0;
    final public static int MAX_X = 9;
    final public static int MAX_Y = 9;

    // The x value of the coordinate, integer 0-9
    private final int x;
    // The y value of the coordinate, integer 0-9
    private final int y;

    /**
     * Default constructor (0, 0)
     */
    public Coordinates() {
        x = 0;
        y = 0;
    }

    /**
     * String constructor
     *
     * @param coordsStr A case-insensitive string that denotes the coordinates of a guess (e.g. A2, b4)
     */
    public Coordinates(String coordsStr) throws Exception {
        if (coordsStr.length() != 2) {
            throw new Exception("Invalid coordinates string");
        }

        coordsStr = coordsStr.toLowerCase();

        char first = coordsStr.charAt(0);
        switch (first) {
            case 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j':
                break;
            default:
                throw new Exception("Invalid letter");
        }

        this.y = first - 'a';
        try {
            this.x = Integer.parseInt(String.valueOf(coordsStr.charAt(1)));
        } catch (NumberFormatException e) {
            throw new Exception("Invalid number");
        }

        if (areInvalid()) {
            throw new Exception("Coordinates out of range");
        }
    }

    /**
     * XY int constructor
     *
     * @param x the x coordinate of the coordinates
     * @param y the y coordinate of the coordinates
     */
    public Coordinates(int x, int y) {
        this.x = x;
        this.y = y;
    }

    //getters

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    /**
     * Checks if the coordinates are invalid
     *
     * @return A boolean indicating if x or y is out of range of the board
     */
    public boolean areInvalid() {
        return x > MAX_X || y > MAX_Y || x < MIN_X || y < MIN_Y;
    }

    /**
     * Gets the coordinates below the current coordinates
     *
     * @return Coordinates below these coordinates
     */
    public Coordinates getBelow(int spaces) {
        return new Coordinates(getX(), getY() + spaces);
    }

    /**
     * Gets the coordinates below the current coordinates
     *
     * @return Coordinates below these coordinates
     */
    public Coordinates getAbove(int spaces) {
        return new Coordinates(getX(), getY() - spaces);
    }

    /**
     * Gets the coordinates left of the current coordinates
     *
     * @return Coordinates right of these coordinates
     */
    public Coordinates getLeft(int spaces) {
        return new Coordinates(getX() - spaces, getY());
    }

    /**
     * Gets the coordinates right of the current coordinates
     *
     * @return Coordinates right of these coordinates
     */
    public Coordinates getRight(int spaces) {
        return new Coordinates(getX() + spaces, getY());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Coordinates that = (Coordinates) o;
        return x == that.x && y == that.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    public static void main(String[] args) throws Exception {
        Coordinates testCoords = new Coordinates();
        System.out.println("Default Coordinates should be (0,0): \n" + testCoords);
        testCoords = new Coordinates(6, 9);
        System.out.println("Setting x to 6 and y to 9: \n" + testCoords);
        testCoords = new Coordinates("G9");
        System.out.println("G9 should equal (9,6): \n" + testCoords);
        testCoords = new Coordinates(6, 6);
        System.out.println("3 spaces above (6,6) is: \n" + testCoords.getAbove(3));
        System.out.println("3 spaces below (6,6) is: \n" + testCoords.getBelow(3));
        System.out.println("3 spaces left of (6,6) is: \n" + testCoords.getLeft(3));
        System.out.println("3 spaces right of (6,6) is: \n" + testCoords.getRight(3));
    }
}