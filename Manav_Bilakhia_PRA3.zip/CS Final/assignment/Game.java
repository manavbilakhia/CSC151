/**
 * Honor code
 * James Heffernan
 */

package assignment;

import java.util.Scanner;

public class Game {
    final static int TURN_PLAYER_1 = 1;
    final static int TURN_PLAYER_2 = 2;

    private String player1;
    private String player2;
    final public Board board1;
    final public Board board2;
    private int turn;

    /**
     * Constructs a new game
     */
    public Game() {
        board1 = new Board();
        board2 = new Board();
        turn = TURN_PLAYER_1;
    }

    /**
     * Gets the current player based on the turn
     *
     * @return the current player
     */
    private String getCurrentPlayer() {
        if (turn == TURN_PLAYER_1) {
            return player1;
        } else {
            return player2;
        }
    }

    /**
     * Gets the board that should be attacked by the current player in this turn
     *
     * @return the current board
     */
    private Board getCurrentBoard() {
        if (turn == TURN_PLAYER_2) {
            return board1;
        } else {
            return board2;
        }
    }

    /**
     * Swaps the turn in the game
     */
    private void swapTurn() {
        if (turn == TURN_PLAYER_1) {
            turn = TURN_PLAYER_2;
        } else {
            turn = TURN_PLAYER_1;
        }
    }

    /**
     * Provides a prompt for firing a shot
     *
     * @param wasHit a boolean indicating if the last shot was a hit
     */
    private void firePrompt(boolean wasHit) {
        if (wasHit) {
            System.out.println("-=== Hit! ===-");
        }

        Board board = getCurrentBoard();
        Coordinates coords = ConsoleDriver.boardCoordinatesPrompt(board, getCurrentPlayer() + ", Enter coordinates to fire: ", false);
        ConsoleDriver.clearConsole();

        boolean hit = board.fire(coords);
        if (board.areAllShipsSunk()) {
            return;
        }

        if (hit) {
            firePrompt(true);
        } else {
            System.out.println("Miss! Hand off to next player in the next 3 seconds.");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException ignored) {

            }
        }
    }

    /**
     * Provides a prompt for placing a ship
     *
     * @param board    the board
     * @param ship     the ship to place, only initialized with size
     * @param reprompt whether this a reprompt due to an error
     */
    private static void placeShipPrompt(Board board, Ship ship, boolean reprompt) {
        Coordinates coords = ConsoleDriver.boardCoordinatesPrompt(board, "Ship: " + ship + "\nEnter coordinates in which to place ship: ", reprompt);

        ship.setCoords(coords);

        try {
            board.addShip(ship);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            placeShipPrompt(board, ship, true);
        }
    }

    /**
     * Provides a prompt for moving a ship
     *
     * @param board    the board
     * @param ship     the ship to move
     * @param reprompt whether this is a reprompt due to an error
     */
    private static void moveShipPrompt(Board board, Ship ship, boolean reprompt) {
        Coordinates coords = ConsoleDriver.boardCoordinatesPrompt(board, "Move the ship to coordinates: ", reprompt);

        try {
            board.moveShip(ship, coords);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            moveShipPrompt(board, ship, true);
        }
    }

    /**
     * Provides a prompt for moving, rotating or confirming a ship
     *
     * @param board    the board
     * @param ship     the ship
     * @param reprompt whether this is a reprompt
     */
    private static void editConfirmShipPrompt(Board board, Ship ship, boolean reprompt) {
        String cmd = ConsoleDriver.boardPrompt(board, "Confirm/edit selection(move, rotate, next/done): ", reprompt);

        switch (cmd) {
            case "next":
            case "done":  // Base case
                return;
            case "move":
                ConsoleDriver.clearConsole();
                moveShipPrompt(board, ship, false);
                break;
            case "rotate":
                try {
                    board.rotateShip(ship);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                break;
            default:
                System.out.println("Invalid command");
                break;
        }

        editConfirmShipPrompt(board, ship, reprompt);
    }

    /**
     * Runs board placement logic
     *
     * @param playerTitle the title of the player (e.g. Player 1, Player 2)
     * @param board       The board of this player
     * @return the name of the player
     */
    private String runBoardPlacement(String playerTitle, Board board) {
        Scanner sc = new Scanner(System.in);
        System.out.print(playerTitle + " enter your name: ");
        String name = sc.next();
        System.out.println("Hello " + name + "! Welcome to Battleship.");

        int[] shipSizes = {2};

        for (int size : shipSizes) {
            Ship ship = new Ship(size);
            placeShipPrompt(board, ship, false);
            ConsoleDriver.clearConsole();
            editConfirmShipPrompt(board, ship, false);
            ConsoleDriver.clearConsole();
        }

        return name;
    }


    /**
     * Runs the game
     */
    private void run() {
        player1 = runBoardPlacement("Player 1", board1);
        ConsoleDriver.clearConsole();
        player2 = runBoardPlacement("Player 2", board2);

        board1.setHideShips(true);
        board2.setHideShips(true);

        while (!board1.areAllShipsSunk() && !board2.areAllShipsSunk()) {
            firePrompt(false);
            swapTurn();
        }

        swapTurn();
        System.out.println("=========================");
        System.out.println(getCurrentPlayer() + " WINS!!!");
        System.out.println("=========================");
        System.out.println("Thank you for playing!");
    }

    public static void main(String[] args) {
        Game game = new Game();
        game.run();
    }
}
