package assignment;
import java.util.Arrays;
import java.util.Stack;
import java.util.StringJoiner;

public class TShirtStack {
//0:S 1:M 2:L 3:XL 4:Big Size You may use a String array

//Constant values for STOCK_LIMIT
    private static int STOCK_LIMIT = 3;
    private Stack<TShirts> red;
    private Stack<TShirts> blue;
    private Stack<TShirts> green;
    private Integer [] sizeInStock; // 0 = small. 1 = mediunm, 2 = large, 3 = XL, 4 = big
    private  Integer [] soldOut;

    //Instance variables red, green, blue Stacks
    //and int arrays sizesInStock and soldOut


    //Parameterless Constructor initialize arrays and stacks
    public TShirtStack()
    {
        red = new Stack<>();
        blue = new Stack<>();
        green=  new Stack<>();
        sizeInStock = new Integer[5];
        soldOut = new Integer[5];
        for (int i = 0; i< sizeInStock.length;i++)
        {
            sizeInStock[i] = 0;
            soldOut[i] = 0;
        }
    }

//addTShirt method
    public void addTShirt(TShirts TShirt)
    {
        String color = TShirt.getColor();
        switch (color){
            case "Red":
                red.push(TShirt);
                sizeInStock[TShirt.getSize()] +=1;
                break;
            case "Blue":
                blue.push(TShirt);
                sizeInStock[TShirt.getSize()] +=1;
                break;
            case "Green":
                green.push(TShirt);
                sizeInStock[TShirt.getSize()] +=1;
                break;
            default:
                System.out.println("you shouldnt be here in add");
                break;
        }
    }
    public void sell(String color)
    {
        switch (color){
            case "red":
                TShirts TShirtRed = red.pop();
                sizeInStock[TShirtRed.getSize()] -=1;
                soldOut[TShirtRed.getSize()] +=1;
                order();
                break;
            case "blue":
                TShirts TShirtBlue =blue.pop();
                sizeInStock[TShirtBlue.getSize()] -=1;
                soldOut[TShirtBlue.getSize()] +=1;
                order();
                break;
            case "green":
                TShirts TShirtGreen =green.pop();
                sizeInStock[TShirtGreen.getSize()]-=1;
                soldOut[TShirtGreen.getSize()] +=1;
                order();
                break;
            default:
                //System.out.println("you shouldnt be here in sell");
                break;
        }
    }
    public void order()
    {
        //System.out.println("you are in the order method");
        for (int i  = 0; i< sizeInStock.length; i++)
        {
           // System.out.println("you are inside order for loop");
            if (sizeInStock[i]< STOCK_LIMIT)
            {
                //System.out.println("you are inside order for loop if statement");
                TShirts TShirtRed = new TShirts(i,"red");
                TShirts TShirtBlue = new TShirts(i,"blue");
                TShirts TShirtGreen = new TShirts(i,"green");
                for (int j = 0; j<STOCK_LIMIT;j++)
                {
                    //System.out.println("you are inside the for loop to add the t shirts");
                    red.push(TShirtRed);
                    blue.push(TShirtBlue);
                    green.push(TShirtGreen);
                    sizeInStock[i] +=3;
                }
            }
        }
    }

    //sell method
    //order method
    //toString method
    @Override
    public String toString()
    {
        Stack<TShirts> redCopy = (Stack<TShirts>)red.clone();
        Stack<TShirts> blueCopy = (Stack<TShirts>)blue.clone();
        Stack<TShirts> greenCopy = (Stack<TShirts>)green.clone();
        String [] size = {"S","M","L","XL","Big"};
        StringJoiner ToReturnRed = new StringJoiner(",");
        String ToReturnGreen ="";
        StringJoiner ToReturnGreen2 =new StringJoiner(",");;
        String ToReturnBlue ="";
        StringJoiner ToReturnBlue2 =new StringJoiner(",");;
        String ToReturnSize ="";
        String ToReturnSold ="";
        String ToReturnHeading = "TShirt Stacks by color \nred=";
        for (int i = 0; i< red.size(); i++)
        {
            int index = redCopy.pop().getSize();
            //System.out.println(index);
            ToReturnRed.add(size[index]);
            //ToReturnRed = size[index]+","+ToReturnRed;
        }
        ToReturnGreen+="\ngreen=";
        for (int i = 0; i< green.size(); i++)
        {
            int index = greenCopy.pop().getSize();
            //System.out.println(index);
            ToReturnGreen2.add(size[index]);
            //ToReturnGreen2 = size[index]+","+ToReturnGreen2;
        }
        ToReturnBlue+="\nblue=";
        for (int i = 0; i< blue.size(); i++)
        {
            int index = blueCopy.pop().getSize();
            //System.out.println(index);
            ToReturnBlue2.add(size[index]);
            //ToReturnBlue2 = size[index]+","+ ToReturnBlue2;
        }
        //ToReturnRed = (ToReturnRed.substring(0, ToReturnRed.length() - 1));
        //ToReturnBlue2 =(ToReturnBlue2.substring(0, ToReturnBlue2.length() - 1));
        //ToReturnGreen2 =(ToReturnGreen2.substring(0, ToReturnGreen2.length() - 1));
        ToReturnSize= "\nsizesInStack=S:"+sizeInStock[0]+" M:"+sizeInStock[1]+" L:"+sizeInStock[2]+" XL:"+sizeInStock[3]+" Big:"+ +sizeInStock[4];
        ToReturnSold= "\nsoldOut=S:"+soldOut[0]+" M:"+soldOut[1]+" L:"+soldOut[2]+" XL:"+soldOut[3]+" Big:"+ +soldOut[4];
        return ToReturnHeading+ToReturnRed+ToReturnGreen + ToReturnGreen2+ToReturnBlue+ ToReturnBlue2+ToReturnSize+ToReturnSold;
    }
//main method. Please change this completely
    public static void main(String[] args) {
        String colors[]= {"Red","Green","Blue"};
        TShirtStack tsh=new TShirtStack();
        System.out.println(tsh);
        for(int i=0;i<5;i++) {
            tsh.addTShirt(new TShirts(i % (1+TShirts.MAX_SIZE), colors[i%3]));
            System.out.println(tsh);
        }
        tsh.sell("red");
        System.out.println(tsh);
        tsh.sell("green");
        System.out.println(tsh);
        tsh.sell("blue");
        System.out.println(tsh);
    }
}
